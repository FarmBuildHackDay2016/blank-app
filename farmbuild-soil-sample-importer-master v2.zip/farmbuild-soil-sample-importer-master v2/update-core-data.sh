#!/bin/bash

rm -fr bower_components/farmbuild-core
rm -fr bower_components/farmbuild-farmdata
bower install
