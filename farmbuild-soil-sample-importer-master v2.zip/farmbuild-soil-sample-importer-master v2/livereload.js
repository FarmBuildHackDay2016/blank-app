module.exports = {
//  paths: [{
//    test: '/path/to/diretory/to/wath'
//  }],
  extensions: ['html', 'css', 'js']
};