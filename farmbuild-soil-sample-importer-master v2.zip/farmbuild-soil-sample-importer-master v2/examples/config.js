'use strict';

window.farmbuild.examples = {
	soilsampleimporter: {
		version: '0.1',
		decimalPrecision: 2
	}
};
