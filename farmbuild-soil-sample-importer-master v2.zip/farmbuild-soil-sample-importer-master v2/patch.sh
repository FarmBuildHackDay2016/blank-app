#!/bin/bash
npm version patch
bower version patch
